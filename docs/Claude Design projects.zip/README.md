# About this download

Copies of Claude Design projects from claude.ai/design, made on November 18, 2026 (UTC). Each project has a folder of its own, and the README.md in it says what is inside.

Before you open a project's folder in a coding tool, or run git or npm in it, look through it for files and folders that such tools read or run without asking (.git, .claude, CLAUDE.md, AGENTS.md, .npmrc and the like, which your computer may hide), and delete any you don't trust, because anyone who could edit the project could have added one.

## In this ZIP

- `PawBook Lịch hẹn 10f89015-ce01/` (project)
- `UI mockups discussion 350c9e0f-4fc7/` (project)
- `Landing page bán template website 55083a8e-ae36/` (project)
- `Fox logo vectorization 60b24062-5c1d/` (project)
- `TranCN logo với con cáo 763b9269-5022/` (project)
- `Chốt mục 8 mô hình dữ liệu 78883361-cc3a/` (project)
- `Nhắc Hạn Dùng thực phẩm 8cb9b882-dab2/` (project)
- `PawBook Landing page ae92e15d-0ba3/` (project)
- `Paw House Spa & Vet c63772f9-b524/` (project)

# Design Brief — Core CMS (Media Platform Admin)

> **Tài liệu này dùng để đưa vào Claude Design.** Mục tiêu: thiết kế lại / nâng cấp giao diện CMS **dựa trên giao diện hiện tại đang chạy thật**, không dựng design system mới từ đầu.
>
> Nguồn dữ liệu: đọc trực tiếp source repo `core-cms-main` (Vue 3 + Vuetify 3, template Able Pro đã mua) **và chụp màn hình thật** toàn bộ 30 route từ dev server `localhost:5173`. Mọi token, số đo, và lỗi nêu dưới đây là quan sát thật, không phải suy đoán.
>
> **Ảnh chụp kèm theo:** thư mục [`docs/design-audit/`](./design-audit/) — 30 ảnh desktop (`d_*.png`, viewport 1440) + 8 ảnh mobile (`m_*.png`, viewport 390). Hãy đính kèm các ảnh này khi đưa tài liệu vào Claude Design.

---

## 0. Cách dùng tài liệu này

1. Dán toàn bộ file này vào Claude Design làm context, kèm ảnh trong `docs/design-audit/`.
2. Đọc **Mục 8 (cần chốt)** trước — có một mâu thuẫn về mô hình dữ liệu ảnh hưởng tới một nửa số màn hình.
3. Thiết kế theo **đúng** token & layout ở Mục 2–3 (ràng buộc cứng, không phải gợi ý).
4. Mục 5 liệt kê lỗi thật quan sát được — đây là danh sách việc cần sửa, không phải danh sách ý tưởng.
5. Mục 7 là thứ tự ưu tiên.

**Nguyên tắc số 1:** codebase là template **mua lại**. Ưu tiên *tái sử dụng / mở rộng* component Vuetify và layout có sẵn hơn là vẽ lại từ đầu. Thiết kế nào không map được về một component Vuetify 3 có sẵn thì chi phí implement cao — cần lý do rõ ràng.

---

## 1. Bối cảnh sản phẩm

**Là gì:** CMS quản trị nội bộ cho một nền tảng media (kho ảnh/video + nội dung xuất bản). Trang xem công khai (viewer site) là dự án riêng, **không** thuộc phạm vi này.

**Người dùng:** hiện tại **chỉ một vai trò `admin`**, toàn quyền, thao tác trực tiếp.
- **Chưa cần** workflow duyệt nhiều bước (draft → review → publish với người duyệt riêng). Trạng thái `draft/published` vẫn là thuộc tính, nhưng không có màn "hàng đợi duyệt" cho reviewer.
- Role `editor` (quyền giới hạn) để sau — đừng thiết kế UI phân quyền phức tạp, nhưng chừa chỗ ẩn/hiện menu.

**Đặc điểm sử dụng:** admin dùng hằng ngày, thao tác lặp lại nhiều (nhập liệu, phân loại, tìm kiếm). Ưu tiên **mật độ thông tin cao + ít click**, không ưu tiên "đẹp mà thưa". Dữ liệu quy mô cá nhân/nhỏ.

**Ngôn ngữ giao diện:** **tiếng Việt là chính**, tiếng Anh phụ. Mọi label/copy trong mockup phải là tiếng Việt. (Locale `fr`/`ro`/`zh` trong repo là di sản template, bỏ qua.)

**Trạng thái kỹ thuật:** backend Laravel **chưa xây**, chưa có API thật — mọi màn hình đang chạy bằng dữ liệu mock hardcode trong component. Vì vậy thiết kế **bắt buộc** phải bao gồm trạng thái loading / rỗng / lỗi.

---

## 2. Design tokens (giá trị thật trong code)

Nguồn: `src/theme/LightTheme.ts`, `src/theme/DarkTheme.ts`, `src/scss/_variables.scss`.
Theme mặc định: `DefaultTheme` (light) / `DarkDefaultTheme` (dark). **Cả 2 chế độ đều phải được thiết kế.**

### 2.1 Bảng màu

| Token | Light | Dark | Dùng cho |
|---|---|---|---|
| `primary` | `#4680FF` | `#6293FF` | Hành động chính, link, active state, focus |
| `darkprimary` | `#3F78FF` | `#3F78FF` | Hover/pressed của primary |
| `lightprimary` | `#E9F0FF` | `#A3C0FF` | Nền nhạt (badge, alert, sidebar item active) |
| `primary200` | `#b8ceff` | `#376DFF` | Viền nhạt, chart phụ |
| `secondary` | `#5B6B79` | `#DBE0E5` | Text phụ, icon phụ, nút phụ |
| `success` | `#2ca87f` | `#2ca87f` | Đã xuất bản / thành công |
| `warning` | `#e58a00` | `#e58a00` | Đang xử lý / cảnh báo |
| `error` | `#dc2626` | `#dc2626` | Lỗi, xoá, Bị khoá |
| `info` | `#3ec9d6` | `#3ec9d6` | Thông tin trung tính, badge verified |
| `surface` | `#ffffff` | `#1D2630` | Nền card / panel / drawer |
| `containerBg` | `#F8F9FA` | `#131920` | Nền toàn trang (phía sau card) |
| `borderLight` / `border-color` | `#e8ebee` | `#29313b` | Viền card, divider |
| `inputBorder` | `#BEC8D0` | `#3E4853` | Viền input, viền phải sidebar (dashed) |
| `darkText` | `#1D2630` | `#dadcde` | Text chính |
| `lightText` | `#5B6B79` | `#798491` | Text phụ, caption, header bảng |
| `gray100` | `#f3f5f7` | `#1D2630` | Nền nhẹ, skeleton, hover row |

Biến thể nền nhạt cho chip/alert (light mode): `lightsuccess #c0e5d9`, `lightwarning #f7dcb3`, `lighterror #f5bebe`, `lightinfo #c5eff3`.
Gradient chuẩn: `linear-gradient(to right, #3F78FF, #4680FF)` — dùng tiết chế.

> Repo có 8 bộ theme màu thay thế (`LightTheme1..8` / `DarkTheme1..8`) đổi được qua customizer. **Đừng thiết kế phụ thuộc vào một mã hex cụ thể** — luôn nghĩ theo token để đổi theme không vỡ.

### 2.2 Typography

Font: **Inter** (`Inter var`, bundle sẵn qua `@fontsource/inter`). Heading cùng font với body. (Roboto / Poppins / Public Sans có sẵn nếu đổi trong customizer — không dùng font ngoài danh sách này.)

| Style | Size | Weight | Line-height | Dùng cho |
|---|---|---|---|---|
| h1 | 2.375rem (38px) | 600 | 1.21 | Trang lỗi |
| h2 | 1.875rem (30px) | 600 | 1.27 | **Tiêu đề trang** (dưới breadcrumb), render weight 700 |
| h3 | 1.5rem (24px) | 600 | 1.33 | Tiêu đề màn auth |
| h4 | 1.25rem (20px) | 600 | 1.40 | Số liệu lớn trong stat card |
| h5 | 1rem (16px) | 600 | 1.50 | Tiêu đề card |
| h6 | 0.875rem (14px) | 400 | 1.57 | Breadcrumb, tiêu đề card (đang dùng `text-h6`) |
| subtitle-1 | 0.875rem | 600 | 1.57 | Tiêu đề `UiParentCard` |
| body-1 | 0.875rem (14px) | 400 | 1.57 | **Text mặc định** |
| body-2 | 0.75rem (12px) | 400 | 1.66 | Text trong bảng, meta |
| button | 0.875rem | 500 | — | Nút — xem cảnh báo bên dưới |
| caption | 0.75rem | 400 | — | Chú thích, timestamp |

> ⚠️ **`button` đang có `text-transform: capitalize`.** Đó là lý do mọi nút hiện ra sai chính tả tiếng Việt: *"Thêm Video"*, *"Đăng Nhập"*, *"Về Trang Chủ"*, *"7 Ngày"*, *"Xem Tất Cả Video →"*. Thiết kế mới phải quy định `text-transform: none` và viết nút theo đúng chính tả tiếng Việt (*"Thêm video"*).

Font-size gốc `1rem = 16px`. Text body mặc định 14px, text trong bảng 12–14px — đây là giao diện mật độ cao, đừng phóng to chữ.

### 2.3 Bo góc, spacing, shadow

- **Radius gốc:** `8px`. Scale: `sm=4px`, mặc định/`md`=`8px`, `lg=12px`, `xl=48px`, `pill=9999px`, `circle=50%`.
- **Mặc định Vuetify** (`src/plugins/vuetify.ts`): `VCard → rounded="md"` (8px), `VTextField → rounded="lg"` (12px). Nhưng **mọi trang thực tế đều override card thành `rounded="lg"` (12px)** → dùng **12px cho card** trong mockup.
- **Padding card đang dùng:** title `pa-4 pb-2` (16px / 8px dưới), body `pa-4` (16px). (Biến SCSS `card-item-spacer-xy: 24px` là mặc định template, không phải cái đang dùng.)
- **Spacing scale:** bội số 4px theo Vuetify (`1=4px … 4=16px, 6=24px, 10=40px`).
- **Shadow:** light `0px 8px 24px rgba(19,25,32,0.08)`; dark `0px 1px 1px rgba(0,0,0,.14), 0px 2px 1px rgba(0,0,0,.12), 0px 1px 3px rgba(0,0,0,.20)`.
  > Thực tế **mọi card đều dùng `elevation="0" variant="outlined"`** — viền 1px, không đổ bóng. Đây là phong cách chủ đạo; shadow chỉ dành cho lớp nổi (menu, dialog, sidebar rail).
- **Gap trong flex:** Vuetify 3 dùng `ga-1..ga-16` (4px–64px). **KHÔNG có class `gap-*`** — xem Mục 5.1.

### 2.4 Icon

- Bộ chính: **MDI** SVG (`@mdi/js`) — `mdi-video`, `mdi-eye`, `mdi-pencil`, `mdi-plus`, `mdi-delete`, `mdi-magnify`, `mdi-flag-outline`, `mdi-check-decagram`…
- Bộ phụ: **SVG sprite của template** (`SvgSprite name="custom-*"`) dùng trong sidebar/header: `custom-home`, `custom-video-play`, `custom-layer`, `custom-tag-outline`, `custom-user-square`, `custom-folder-open`, `custom-user`, `custom-message-2`, `custom-shield`, `custom-bag`, `custom-graph`, `custom-setting-2`, `custom-search`, `custom-menu-outline`, `custom-translation`, `custom-chevron-outline`, `custom-eye`, `custom-eye-invisible`.
- Size hay dùng: 16px (inline), 20px (sidebar), 24px (nút header), 28px (trong avatar stat card), 48px (empty state).
- **Không nhúng bộ icon thứ ba.**

---

## 3. Layout khung (đo từ code + ảnh chụp)

```
┌──────────────┬──────────────────────────────────────────────┐
│              │  Header (app-bar)  height 74px, elevation 0  │
│  Sidebar     │  padding-x 40px (sm+) / 20px (xs)            │
│  width 279px ├──────────────────────────────────────────────┤
│  (rail 90px) │  Content — nền containerBg                   │
│              │  padding-x 40px (≥768) / 16px (mobile)       │
│  nền:        │  padding-top 20px                            │
│  containerBg │                                              │
│  viền phải:  │   Breadcrumb: Trang chủ › … (h6, chevron 12px)│
│  1px dashed  │   Tiêu đề trang: h2 weight 700               │
│  inputBorder │                                              │
│              │   ┌ Card: viền 1px, radius 12px, no shadow ┐ │
│              │   │  nền surface                           │ │
│              │   └────────────────────────────────────────┘ │
├──────────────┴──────────────────────────────────────────────┤
│  Footer — caption, 2 cột (trái copyright, phải 3 link)      │
└─────────────────────────────────────────────────────────────┘
```

| Thành phần | Giá trị |
|---|---|
| Sidebar width | `279px` (mở), `90px` (rail, có shadow) |
| Header height | `74px` |
| Content padding-x | `40px` (≥768px), `16px` (mobile) |
| Content padding-top | `20px` |
| Content min-height | `calc(100vh - 139px)` |
| Boxed mode (tuỳ chọn) | content max-width `1200px`, căn giữa |
| Sidebar chuyển overlay | dưới `lg` (<1280px) |
| Breakpoints (Vuetify 3) | xs <600 · sm ≥600 · md ≥960 · lg ≥1280 · xl ≥1920 |

### 3.1 Sidebar — menu hiện tại

Cấu trúc: logo (padding 20px) → danh sách cuộn (`calc(100vh - 79px)`). Kiểu item: **group header** (chữ nhỏ, weight 600, màu lightText, viết hoa) → **item** (icon 20px + label) → **collapse** (item con có bullet tròn 5px) → **divider** giữa nhóm. Item active: nền `lightprimary` bo góc + chữ/icon `primary`.

```
[TỔNG QUAN]
  Dashboard                        /dashboard
[NỘI DUNG]
  Video          ▾ Danh sách video      /videos
                   Thêm video           /videos/create
  Danh mục       ▾ Danh sách danh mục   /categories
                   Thêm danh mục        /categories/create
  Tags                                  /tags
  Kênh           ▾ Danh sách kênh       /channels
                   Thêm kênh            /channels/create
  Playlist                              /playlists
[NGƯỜI DÙNG & TƯƠNG TÁC]
  Người dùng     ▾ Danh sách            /users
                   Thêm người dùng      /users/create
  Bình luận                             /comments
  Báo cáo vi phạm                       /reports
[VẬN HÀNH]
  Quảng cáo      ▾ Danh sách quảng cáo  /ads
                   Thêm quảng cáo       /ads/create
  Thống kê                              /analytics/videos
  Cài đặt        ▾ Cài đặt chung        /settings/general
                   Lưu trữ / SEO / Email / Quản trị viên
```

### 3.2 Header

Trái → phải: nút thu gọn sidebar (icon tonal, rounded `sm`) → ô tìm kiếm global width 224px, placeholder `Ctrl + k` (ẩn dưới lg → thu thành icon) → *spacer* → mega-menu → đổi ngôn ngữ → thông báo (badge số) → messages → avatar profile.
> Mega-menu, notification, messages hiện còn là nội dung demo của template. Thiết kế lại hoặc lược bỏ — cần chốt (Mục 8).

### 3.3 Biến thể có sẵn không cần thiết kế

Layout ngang (`HorizontalHeader` + `HorizontalSidebar`) và **Customizer panel** (đổi theme màu / sáng-tối / font / layout / boxed) là tính năng sẵn của template. Không cần thiết kế lại, nhưng thiết kế mới **phải sống được** với cả 9 bộ màu và cả 2 chế độ sáng/tối.

---

## 4. Mẫu trang (page patterns) đang dùng

### 4.1 Trang danh sách — khuôn phổ biến nhất

```
Breadcrumb → Tiêu đề trang (h2)
┌─ Card (viền 1px, radius 12px) ───────────────────────────────┐
│  [🔍 Ô tìm kiếm ~5/12] [Select trạng thái ~3/12]             │
│                              [Xoá (n)] [+ Thêm mới] ← phải   │
│  ┌ Bảng density="compact" ────────────────────────────────┐  │
│  │ ☐ │ Tiêu đề (thumb 56×32 + link) │ … │ Chip │ 👁 ✏️     │  │
│  └────────────────────────────────────────────────────────┘  │
│  Hiển thị 1–10 / 128 video            ‹ 1 2 3 … ›            │
└──────────────────────────────────────────────────────────────┘
```

- Ô tìm kiếm: `variant="outlined" density="compact" hide-details`, icon `mdi-magnify` trong trái.
- Nút chính: `color="primary" size="small" prepend-icon="mdi-plus"`.
- Nút xoá hàng loạt: `color="error" variant="tonal" size="small"`, chỉ hiện khi có dòng chọn, kèm số lượng.
- Bảng: `<v-table density="compact">`; cột số căn **phải**; cột thao tác cuối (icon button `size="x-small" variant="text"`).
- Chip trạng thái: `size="x-small" variant="tonal"`.
- Loading: `v-skeleton-loader type="table-row"` × 5 (không dùng spinner toàn trang).
- Empty state: icon 48px xám + dòng `body-2` + nút CTA `size="small"`, padding dọc 48px.
- Phân trang: trái "Hiển thị X–Y / Z", phải `v-pagination density="compact" :total-visible="5"`.
- Dialog xoá: `max-width 420`, radius 12px, title h6, nội dung nêu số lượng + "không thể hoàn tác", nút `Huỷ` (text) + `Xoá` (error tonal).

### 4.2 Trang form

Bố cục **8/4** (`lg`+, dồn 1 cột ở dưới): cột trái card nội dung chính; cột phải card "Xuất bản" + "Phân loại" + cặp nút `[Huỷ (outlined)] [Lưu/Tạo (primary)]`.
Card: title `pa-4 pb-2 text-h6` + `v-divider` + body `pa-4`. Input `variant="outlined" density="compact"`, cách nhau `mb-3`.
> Category form và Channel form lại dùng bố cục **căn giữa 6/12** và đặt nút trong `v-card-actions` — không nhất quán với Video form. Cần chốt một khuôn.

### 4.3 Dashboard

- **Hàng stat card:** 4 card `cols=12 sm=6 lg=3`. Mỗi card: label `caption` mờ → số `h4` bold → dòng tăng trưởng (`+8.2% so với hôm qua`, màu success/warning) — bên phải **avatar vuông `rounded="lg"` 52px, nền màu ngữ nghĩa, icon trắng 28px**.
- **Hàng dưới:** 8/12 bảng "Top video xem nhiều nhất" (title + divider + bảng + card-actions link "Xem tất cả →"); 4/12 card "Thao tác nhanh" (lưới 2×2 nút `variant="tonal" block size="small"`) + card "Báo cáo chờ xử lý" (`v-list lines="two"`, avatar vuông 36px + title `body-2` + thời gian `caption`).
- **Chưa có biểu đồ nào.** Trang `/analytics/videos` có ô placeholder ghi *"Biểu đồ lượt xem theo ngày (Tích hợp ApexCharts / Chart.js)"*.

### 4.4 Trang chi tiết

Có cho video / kênh / người dùng / báo cáo / playlist. Kiểu chung: khối tóm tắt (avatar lớn 80px + tên + chip) hoặc media preview 16:9, kèm card `v-list` dạng **label trái – giá trị phải**, cộng hàng 3 ô số liệu (`text-h4` + caption) và bảng liên quan.

### 4.5 Trang cài đặt

5 route rời (`general`, `storage`, `seo`, `email`, `admins`). Trang `general` có card "Điều hướng nhanh" ở cột phải để nhảy sang 4 trang còn lại — dấu hiệu rõ là **nên gộp thành tab/sub-nav** thay vì 5 route rời.

### 4.6 Trang auth

`BlankLayout`, không sidebar/header. Card căn giữa **max-width 475px**, `variant="outlined" rounded="lg"`, padding 40px, tiêu đề `h3`, input có `v-label` riêng phía trên (không floating label), nút submit `block size="large" rounded="md" variant="flat"`.

### 4.7 Trang lỗi

404/403 dùng illustration sẵn của template (tông cam/xanh, lệch với primary xanh dương), `h1` + `text-h6` mô tả + nút về trang chủ.

---

## 5. Audit hiện trạng — lỗi thật quan sát được

> Đây là **danh sách việc cần sửa**, đối chiếu được với ảnh trong `docs/design-audit/`.

### 5.1 Lỗi hệ thống (ảnh hưởng nhiều trang)

| # | Lỗi | Bằng chứng |
|---|---|---|
| 1 | **Class `gap-*` không tồn tại trong Vuetify 3** — đúng phải là `ga-*`. Có **24 chỗ** dùng `gap-1/2/3` trong `src/**/*.vue`, tất cả đều vô hiệu. | `d_video-list.png`: thumbnail **đè lên** tiêu đề video. `d_user-list.png`: avatar dính sát tên. `d_video-create.png`: nút "Huỷ" và "Tạo Video" chạm nhau, nút "Thêm" dính ô nhập tag. `d_video-detail.png`: hàng meta dính liền *"128.400 lượt xem4.820120324 bình luận1:24:00"*. |
| 2 | **Nút viết hoa từng chữ, sai chính tả tiếng Việt** (do `button: text-transform: capitalize`). | "Thêm Video", "Đăng Nhập", "Về Trang Chủ", "7 Ngày", "Xem Tất Cả Video →", "Chỉnh Sửa", "Khoá Video" — thấy ở gần như mọi ảnh. |
| 3 | **Enum tiếng Anh lọt ra giao diện** — chưa có bảng nhãn tiếng Việt. | `d_video-detail.png`: chip `published`, `approved`, `pending`. `d_user-list.png`: `creator`, `viewer`, `moderator`, `admin`. `d_report-detail.png`: `video`/`comment`. |
| 4 | **Mobile không dùng được**: sidebar drawer mặc định **mở** và phủ kín màn 390px; nội dung phía sau bị bảng tràn ngang, mất cột. | `m_dashboard.png`, `m_video-list.png` — drawer chiếm 279/390px, chỉ thấy vài cột bảng bị cắt. |
| 5 | **Thương hiệu vẫn là của template**: logo "Able Pro", footer "© Able Pro ❤ crafted by Team Phoenixcoded" + link Home/Documentation/Support, avatar profile là ảnh demo. | Mọi ảnh desktop. |
| 6 | **Khoảng trắng chết ~50% chiều cao** ở hầu hết trang — nội dung ngắn, footer bị đẩy xuống đáy. | `d_video-list.png`, `d_comment-list.png`, `d_user-list.png`, `d_analytics.png`. |
| 7 | **Bảng tràn sát mép card** — `v-table` đặt trong `v-card-text` nên không thẳng hàng với toolbar phía trên. | `d_video-list.png`, `d_user-list.png`. |
| 8 | **Cột thao tác 80px quá hẹp** → 2 icon button xuống dòng, chiều cao hàng gấp đôi. | `d_video-list.png` (cột 👁 / ✏️ xếp dọc). |
| 9 | **Nút customizer (bánh răng) nổi đè lên nội dung** mép phải, che góc card. | `d_video-create.png`, `d_video-detail.png`, `d_analytics.png`. |
| 10 | **Màu hardcode sẽ hỏng ở dark mode**: `bg-grey-lighten-4` (placeholder biểu đồ), `bg-grey-lighten-3` (placeholder ảnh), `text-grey-lighten-2` (icon empty state). | `d_analytics.png`. |
| 11 | **Trang đăng nhập còn rác copy-paste**: breadcrumb *"Trang chủ › Danh sách trung tâm › Cập nhật trung tâm"* hiện ngay đầu trang; không có logo; không có link "Quên mật khẩu"; đăng nhập bằng **số điện thoại**. | `d_login.png`. |
| 12 | **Trang quên mật khẩu còn là vỏ rỗng**, tiêu đề tiếng Anh "Forgot Password", không có ô nhập nào. | `d_forgot-password.png`. |

### 5.2 Không nhất quán giữa các trang

| Hạng mục | Tình trạng |
|---|---|
| Stat card | Dashboard: avatar **52px** + dòng tăng trưởng. Analytics: avatar **48px**, không có tăng trưởng. |
| Label input | 3 kiểu song song: floating label (form video/category), placeholder không label (ô tìm kiếm), `v-label` rời phía trên (login, ô tag). |
| Nút hành động form | Video form: **ngoài** card, cuối cột phải. Category/Channel form: **trong** `v-card-actions`. Settings: trong `v-card-actions` của card thứ 2. |
| Bố cục form | Video 8/4 · Category & Channel căn giữa 6/12 · Settings 8/4 · Storage căn giữa 8/12. |
| Skeleton loading | Chỉ có ở Video list & User list. 8 trang danh sách còn lại không có. |
| Empty state đầy đủ | Chỉ Video list & User list (icon + text + CTA). Comments/Reports/Ads chỉ 1 dòng text. Categories/Tags/Playlists/Channels **không có gì**. |
| Phân trang | Chỉ Video list & User list. Các trang khác render toàn bộ mảng. |
| Hành động trên dòng | Comments **không có** nút duyệt/từ chối inline — phải tick chọn rồi mới hiện nút bulk. |
| Bộ lọc | Video/User/Comment/Report/Ad/Channel có select trạng thái; Categories/Tags/Playlists chỉ có ô tìm kiếm. Không trang nào có lọc theo khoảng ngày. |
| Select không nhãn | `d_user-list.png`: select thứ hai chỉ ghi "Tất cả" — không rõ đang lọc gì. |

### 5.3 Điểm đã tốt — nên giữ nguyên

- Sidebar 3 nhóm rõ ràng, icon nhất quán, active state (nền `lightprimary` bo góc + chữ primary) đọc tốt.
- Cặp breadcrumb + `h2` tiêu đề trang: nhận diện vị trí nhanh.
- Card viền mỏng không đổ bóng, radius 12px — sạch, hợp giao diện mật độ cao.
- Chip trạng thái `tonal x-small` — nhỏ gọn, đủ tương phản.
- Toolbar danh sách (tìm kiếm trái · select giữa · nút primary phải) — đã đúng quy ước, giữ.
- Bảng "Top video hiệu suất cao" (`d_analytics.png`) là bảng trình bày tốt nhất hiện có: cột số căn phải, CTR màu success.

---

## 6. Danh sách màn hình

### 6.1 Đã có trong code (30 route, đều có ảnh chụp)

| Nhóm | Route | Ảnh | Đánh giá |
|---|---|---|---|
| Dashboard | `/dashboard` | `d_dashboard` `m_dashboard` | Khá hoàn chỉnh; thiếu biểu đồ; "Báo cáo chờ xử lý" là dữ liệu hardcode |
| Video | `/videos` | `d_video-list` `m_video-list` | Khuôn tốt nhất nhưng **vỡ layout** (lỗi 1, 7, 8) |
| Video | `/videos/create` `/videos/:id/edit` | `d_video-create` `m_video-create` | Bố cục 8/4 tốt; nút dính nhau; **chưa có UI upload/tiến độ** |
| Video | `/videos/:id` | `d_video-detail` `m_video-detail` | Meta dính liền; chip enum tiếng Anh |
| Danh mục | `/categories` `/categories/create` `/categories/:id/edit` | `d_category-*` | **Không có tree view thật** — chỉ prefix ký tự `└`; không empty state |
| Tags | `/tags` | `d_tag-list` | Đã có inline quick-edit (chip → ô nhập); card "Thêm tag mới" 4/12 riêng |
| Kênh | `/channels` `/channels/create` `/channels/:id/edit` `/channels/:id` | `d_channel-*` | Thô; detail có 3 ô số liệu + bảng video gần đây |
| Playlist | `/playlists` `/playlists/:id` | `d_playlist-*` | Thô; **chưa có kéo-thả sắp xếp** (chỉ hiện số thứ tự tĩnh) |
| Người dùng | `/users` `/users/create` `/users/:id/edit` `/users/:id` | `d_user-*` `m_user-list` | Hàng bảng chật, avatar dính chữ, role chưa Việt hoá |
| Bình luận | `/comments` | `d_comment-list` | Trình bày sạch nhất; thiếu action inline, thiếu avatar, thiếu thread |
| Báo cáo | `/reports` `/reports/:id` | `d_report-*` | Detail dạng `v-list` label–value, có 3 nút xử lý |
| Quảng cáo | `/ads` `/ads/create` | `d_ad-*` | Bảng có CTR tính sẵn; thô |
| Thống kê | `/analytics/videos` | `d_analytics` `m_analytics` | Có `v-btn-toggle` khoảng thời gian; **biểu đồ là ô placeholder rỗng** |
| Cài đặt | `/settings/{general,storage,seo,email,admins}` | `d_settings-*` `m_settings-general` | 5 route rời; `general` có card điều hướng nhanh; `storage` gắn cứng S3/GCS/R2 |
| Auth | `/login` `/forgot-password` | `d_login` `m_login` `d_forgot-password` | Lỗi 11, 12 |
| Lỗi | 404 (catch-all) · 403 tại `/error` | `d_error-404` `d_error-403` | Illustration template lệch tông màu, khoảng cách chữ chật. Lưu ý: route 403 là `/error`, không phải `/403` |

### 6.2 Còn thiếu hoàn toàn — cần thiết kế mới

- **Luồng upload media**: chọn file → tiến độ → đang transcode → lỗi → huỷ. Đây là luồng nghiệp vụ trung tâm mà chưa có gì.
- **Media picker / thư viện media** dạng lưới thumbnail để chọn khi tạo nội dung.
- **Hệ thống badge/chip trạng thái** — bảng nhãn tiếng Việt + màu cho toàn bộ enum (Mục 6.3).
- **Trạng thái rỗng / lỗi tải / không có quyền** cho 8 trang danh sách còn thiếu.
- **Toast thông báo kết quả** (đã cài `vue-toast-notification`, chưa có mẫu).
- **Bộ lọc nâng cao** (nhiều điều kiện, khoảng ngày) — hiện tối đa 1 ô tìm kiếm + 2 select.
- **Phương án bảng trên mobile** — hiện chắc chắn vỡ.
- **Trang hồ sơ admin / đổi mật khẩu.**
- **Biểu đồ** cho Dashboard + Analytics.
- **Skeleton chuẩn** cho form và trang chi tiết (hiện chỉ có cho bảng).

### 6.3 Enum cần chốt nhãn tiếng Việt + màu

Đang dùng nhất quán:

| Trạng thái | Nhãn | Màu |
|---|---|---|
| `published` | Đã xuất bản | `success` |
| `draft` | Bản nháp | `grey` |
| `processing` | Đang xử lý | `warning` |
| `blocked` | Bị khoá | `error` |

**Chưa có nhãn/màu thống nhất** (định nghĩa trong `src/types/media/index.ts`, hiện hoặc hiển thị enum thô hoặc mỗi trang tự đặt):
`unlisted` · `ChannelStatus` (active/inactive/suspended) · `UserRole` (viewer/creator/moderator/admin) · `UserStatus` (active/inactive/banned) · `CommentStatus` (approved/pending/rejected/deleted) · `ReportStatus` (pending/reviewed/resolved/dismissed) · `ReportReason` (spam/violence/copyright/sexual/misinformation/other) · `PlaylistVisibility` (public/unlisted/private) · `AdType` (pre_roll/mid_roll/banner/overlay) · `AdStatus` (active/paused/expired).

> **Đề nghị Claude Design:** làm một artboard riêng *"Status & Badge system"* chốt nhãn + màu + biến thể cho toàn bộ enum trên. Đây là hạng mục thiếu rõ nhất hiện nay.

### 6.4 Quy ước copy tiếng Việt (giữ để mockup khớp code)

- Hành động: `Thêm video`, `Lưu thay đổi`, `Tạo video`, `Huỷ`, `Xoá`, `Xác nhận xoá`, `Xem tất cả →`.
- Lọc: `Tìm kiếm video, kênh...`, `Tất cả trạng thái`.
- Rỗng: `Không tìm thấy video nào`, `Chưa có dữ liệu`, `Thêm video đầu tiên`.
- Phân trang: `Hiển thị 1–10 / 128 video`.
- Breadcrumb luôn bắt đầu `Trang chủ`, phân cách chevron 12px.
- Số theo `vi-VN` (`1.234.567`); ngày `dd/mm/yyyy`; thời lượng `mm:ss` / `h:mm:ss`; giá trị trống `—`.
- Text tiếng Việt dài hơn tiếng Anh ~20–30% → chừa chỗ, đừng thiết kế nút vừa khít.

---

## 7. Thứ tự ưu tiên đề xuất

1. **Design system sheet** — token, typography (sửa `capitalize`), spacing/gap, button · input · chip · table · card ở mọi state, light + dark. Nền của tất cả phần sau.
2. **Status & Badge system** (Mục 6.3) — chốt nhãn tiếng Việt cho mọi enum.
3. **Khuôn trang danh sách chuẩn** — sửa lỗi 1/7/8, kèm đủ 4 trạng thái (có dữ liệu / loading / rỗng / lỗi) và phương án mobile.
4. **Khuôn trang form chuẩn** — thống nhất 1 bố cục, 1 kiểu label, 1 vị trí nút — **cộng luồng upload media**.
5. **Dashboard + Analytics** (bao gồm biểu đồ).
6. **Trang chi tiết** (video, kênh, người dùng).
7. **Bình luận + Báo cáo** — màn thao tác hàng loạt, cần action inline.
8. **Cài đặt** (gộp tab) + trang hồ sơ admin.
9. **Auth + trang lỗi + thương hiệu** (logo, footer).

**Kích thước artboard:** desktop `1440×900` (chính), mobile `390×844`. Ít nhất khuôn danh sách + form phải có bản mobile.

---

## 8. Cần chốt trước khi thiết kế

> ⚠️ **Mục quan trọng nhất.**

### 8.1 Mô hình dữ liệu: nền tảng video công khai, hay kho media nội bộ?

Hai mô tả **không khớp**:

| | `CLAUDE.md` (định hướng) | Code hiện tại + `docs/media-platform-plan.md` |
|---|---|---|
| Thực thể | **Media** (file gốc: title, duration, type image/video) + **Post** (nội dung tham chiếu 1 `media_id`, có cast riêng) | **Video** (thuộc **Channel**) |
| Phân loại | **Cast** (diễn viên) + **Genre** (phim/hài/kịch) | **Category** (cây cha-con) + **Tag** |
| Người dùng | Chỉ `admin` | `viewer/creator/moderator/admin` + đăng ký, subscribe |
| Tương tác | Không đề cập | Bình luận, like/dislike, playlist, báo cáo vi phạm, quảng cáo |

Code đã scaffold theo mô hình **YouTube thu nhỏ**, còn định hướng lại mô tả **kho media + nội dung xuất bản, một admin duy nhất, không có cộng đồng người dùng**. Khoảng một nửa số màn hình hiện có (Kênh, Bình luận, Báo cáo, Playlist, Quảng cáo, Người dùng đa vai trò) chỉ tồn tại ở mô hình thứ hai.

- **(a)** Giữ mô hình video platform → thiết kế đủ 30 màn hình.
- **(b)** Quay về mô hình Media/Post/Cast/Genre → **bỏ** Kênh/Bình luận/Báo cáo/Playlist/Quảng cáo, **đổi tên** Category→Genre, **thêm** Cast, **tách** Media và Post thành hai nhóm màn hình. Còn ~12–15 màn hình.

Chọn (b) tiết kiệm phần lớn công thiết kế; chọn (a) phải chấp nhận thiết kế cả những màn có thể không bao giờ dùng.

### 8.2 Câu hỏi nhỏ hơn

1. **Đăng nhập bằng gì?** Code dùng **số điện thoại** (validate 10 số); mockup cũ trong `html/` dùng **email**.
2. **Thương hiệu:** logo cáo (`html/fox-logo-*.svg`) có phải logo chính thức? Tên hiển thị của CMS là gì? (Logo và footer hiện vẫn là "Able Pro".)
3. **Giữ hay bỏ tính năng template?** Mega-menu, đổi ngôn ngữ trên header, customizer panel, layout ngang, 9 bộ theme màu, notification/messages dropdown.
4. **Lưu trữ media:** hiện đọc từ ổ đĩa local máy dev, dự kiến chuyển **MinIO** nhưng chưa setup. Trang "Cài đặt → Lưu trữ" đang gắn cứng S3/GCS/R2 — nên thiết kế trung lập hoặc đổi sang MinIO.
5. **Biểu đồ:** cần loại nào (đường/cột/tròn)? Repo **chưa có** thư viện chart — được thêm ApexCharts/Chart.js không?
6. **Bảng trên mobile:** cuộn ngang, ẩn bớt cột, hay đổi sang dạng card?
7. **Sidebar trên mobile** nên mặc định **đóng** — xác nhận?

---

## 9. Phụ lục — bản đồ file tham chiếu

| Cần gì | Xem file |
|---|---|
| Ảnh chụp hiện trạng | `docs/design-audit/` (`d_*` desktop 1440, `m_*` mobile 390) |
| Token màu | `src/theme/LightTheme.ts`, `src/theme/DarkTheme.ts` |
| Typography, radius, spacing, shadow | `src/scss/_variables.scss` |
| Mặc định component Vuetify | `src/plugins/vuetify.ts` |
| Khung layout dashboard | `src/layouts/dashboard/DashboardLayout.vue` |
| Sidebar + menu | `src/layouts/dashboard/vertical-sidebar/` (`sidebarItem.ts`) |
| Header | `src/layouts/dashboard/vertical-header/VerticalHeader.vue` |
| Component dùng chung | `src/components/shared/` (`BaseBreadcrumb`, `UiParentCard`, `DatePicker`, `PaginationCommon`, `SvgSprite`) |
| Mẫu list / form / dashboard | `src/pages/videos/VideoListPage.vue`, `VideoFormPage.vue`, `src/pages/dashboard/DashboardPage.vue` |
| Toàn bộ route | `src/router/MainRoutes.ts`, `src/router/AuthRoutes.ts` |
| Kiểu dữ liệu / enum | `src/types/media/index.ts` |
| CSS layout (số đo) | `src/scss/layout/_sidebar.scss`, `_container.scss`, `_topbar.scss` |
| Mockup cũ (tiếng Anh, tham khảo) | `html/CMS Mockups.dc.html` |
| Kế hoạch sản phẩm (file bị lỗi font tiếng Việt) | `docs/media-platform-plan.md` |
